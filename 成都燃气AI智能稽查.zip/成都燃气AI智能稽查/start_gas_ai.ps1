$ErrorActionPreference = 'Stop'
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = 'C:\Users\J11\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) {
  $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
  if ($pythonCommand) { $pythonExe = $pythonCommand.Source } else {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show('Python is not installed. Install Python 3.10 or newer, then run this file again.', 'Gas AI') | Out-Null
    exit 1
  }
}

try { & $pythonExe -c "import numpy, openpyxl" 2>$null } catch {
  $requirements = Join-Path $appDir 'requirements.txt'
  & $pythonExe -m pip install -r $requirements
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
$serviceUrl = 'http://127.0.0.1:4173/api/health'
$running = $false
try { Invoke-WebRequest -UseBasicParsing -Uri $serviceUrl -TimeoutSec 1 | Out-Null; $running = $true } catch { }
if (-not $running) {
  Start-Process -FilePath $pythonExe -ArgumentList @('server.py') -WorkingDirectory $appDir -WindowStyle Minimized | Out-Null
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 250
    try { Invoke-WebRequest -UseBasicParsing -Uri $serviceUrl -TimeoutSec 1 | Out-Null; $running = $true; break } catch { }
  }
}
if (-not $running) {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show('Service failed to start. Please check that Python is installed.', 'Gas AI') | Out-Null
  exit 1
}
Start-Process explorer.exe 'http://127.0.0.1:4173/'
