$appProcesses = Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -like '*gas-ai-app*server.py*' }
if ($appProcesses) {
  $appProcesses | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
  Write-Host '燃气智稽服务已停止。'
} else {
  Write-Host '未发现正在运行的燃气智稽服务。'
}
