from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import numpy as np


TYPE_ORDER = ["餐饮", "工业", "商业", "酒店"]


@dataclass
class NeuralGasModel:
    seed: int = 42
    epochs: int = 420
    learning_rate: float = 0.008

    def _features(self, rows: list[dict[str, Any]], profiles: dict[str, dict[str, Any]]):
        dates = [self._date(row["date"]) for row in rows]
        first_date = min(dates)
        raw = []
        for row, day in zip(rows, dates):
            profile = profiles[row["user_id"]]
            weekday = day.weekday()
            user_type = profile["user_type"]
            raw.append([
                float(row["temperature_c"]),
                math.sin(2 * math.pi * weekday / 7),
                math.cos(2 * math.pi * weekday / 7),
                (day - first_date).days / 365,
                float(row.get("is_holiday", 0)),
                math.log1p(float(profile.get("contract_capacity_m3", 500))),
                *[1.0 if user_type == item else 0.0 for item in TYPE_ORDER],
            ])
        return np.asarray(raw, dtype=np.float64), dates

    @staticmethod
    def _date(value: Any):
        if isinstance(value, datetime):
            return value.date()
        if hasattr(value, "year") and hasattr(value, "month") and hasattr(value, "day"):
            return value
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()

    def fit_predict(self, rows: list[dict[str, Any]], profile_rows: list[dict[str, Any]]):
        profiles = {row["user_id"]: row for row in profile_rows}
        x_raw, dates = self._features(rows, profiles)
        y_raw = np.asarray([float(row["meter_reading_m3"]) for row in rows], dtype=np.float64).reshape(-1, 1)

        cutoff = sorted(set(dates))[max(1, int(len(set(dates)) * 0.68)) - 1]
        train_mask = np.asarray([day <= cutoff for day in dates])
        x_mean, x_std = x_raw[train_mask].mean(0), x_raw[train_mask].std(0) + 1e-6
        y_mean, y_std = y_raw[train_mask].mean(0), y_raw[train_mask].std(0) + 1e-6
        x = (x_raw - x_mean) / x_std
        y = (y_raw - y_mean) / y_std

        rng = np.random.default_rng(self.seed)
        dims = [x.shape[1], 24, 12, 1]
        weights = [rng.normal(0, math.sqrt(2 / dims[i]), (dims[i], dims[i + 1])) for i in range(3)]
        biases = [np.zeros((1, dims[i + 1])) for i in range(3)]

        xt, yt = x[train_mask], y[train_mask]
        for _ in range(self.epochs):
            z1 = xt @ weights[0] + biases[0]
            a1 = np.maximum(z1, 0)
            z2 = a1 @ weights[1] + biases[1]
            a2 = np.maximum(z2, 0)
            pred = a2 @ weights[2] + biases[2]
            delta = 2 * (pred - yt) / len(yt)
            grads_w = [None, None, None]
            grads_b = [None, None, None]
            grads_w[2], grads_b[2] = a2.T @ delta, delta.sum(0, keepdims=True)
            delta = (delta @ weights[2].T) * (z2 > 0)
            grads_w[1], grads_b[1] = a1.T @ delta, delta.sum(0, keepdims=True)
            delta = (delta @ weights[1].T) * (z1 > 0)
            grads_w[0], grads_b[0] = xt.T @ delta, delta.sum(0, keepdims=True)
            for index in range(3):
                weights[index] -= self.learning_rate * np.clip(grads_w[index], -1, 1)
                biases[index] -= self.learning_rate * np.clip(grads_b[index], -1, 1)

        a1 = np.maximum(x @ weights[0] + biases[0], 0)
        a2 = np.maximum(a1 @ weights[1] + biases[1], 0)
        predicted = np.maximum((a2 @ weights[2] + biases[2]) * y_std + y_mean, 0).ravel()
        train_pred = predicted[train_mask]
        mae = float(np.mean(np.abs(train_pred - y_raw[train_mask].ravel())))
        rmse = float(np.sqrt(np.mean((train_pred - y_raw[train_mask].ravel()) ** 2)))
        return self._summarize(rows, profile_rows, dates, predicted, mae, rmse, cutoff)

    def _summarize(self, rows, profile_rows, dates, predicted, mae, rmse, cutoff):
        by_user: dict[str, list[int]] = {}
        for index, row in enumerate(rows):
            by_user.setdefault(row["user_id"], []).append(index)

        results = []
        max_date = max(dates)
        recent_start = max_date.fromordinal(max_date.toordinal() - 44)
        for profile in profile_rows:
            uid = profile["user_id"]
            indexes = by_user.get(uid, [])
            recent = [i for i in indexes if dates[i] >= recent_start]
            actual = np.asarray([float(rows[i]["meter_reading_m3"]) for i in recent])
            expected = predicted[recent]
            deficit = np.maximum(expected - actual, 0)
            deviation = float(deficit.sum() / max(expected.sum(), 1))
            anomaly_rate = float(np.mean(actual < expected * 0.72)) if len(actual) else 0
            payment_penalty = max(0, (75 - float(profile.get("payment_score", 80))) / 100)
            risk = int(round(min(99, max(8, 18 + deviation * 95 + anomaly_rate * 24 + payment_penalty * 14))))
            priority = "紧急" if risk >= 85 else "高" if risk >= 70 else "中" if risk >= 45 else "低"
            loss = float(deficit.sum())
            price = float(profile.get("gas_price_yuan", 3.65))
            if deviation > 0.32:
                reason = f"近45日计量气量较神经网络预测低{deviation:.0%}，异常日占比{anomaly_rate:.0%}"
            elif deviation > 0.16:
                reason = f"近期用气较正常基线低{deviation:.0%}，营业周期与同类用户偏差扩大"
            else:
                reason = "用气曲线总体处于正常预测区间"
            series_indexes = indexes[-90:]
            series = [{
                "date": dates[i].isoformat(),
                "actual": round(float(rows[i]["meter_reading_m3"]), 1),
                "predicted": round(float(predicted[i]), 1),
                "temperature": round(float(rows[i]["temperature_c"]), 1),
            } for i in series_indexes]
            recovery_type = "重点追缴型" if risk >= 85 and float(profile.get("payment_score", 80)) < 70 else "协商追缴型" if loss * price >= 50000 else "正常追缴型"
            recovery_advice = {
                "正常追缴型": "电话或短信通知，限期一次性补缴，并登记到账结果。",
                "协商追缴型": "优先人工沟通；在企业制度允许范围内确认一次性或分期方案，并持续跟踪履约。",
                "重点追缴型": "安排重点人员跟进，发出正式通知；符合制度条件后转入上门及法务流程。",
            }[recovery_type]
            results.append({
                **profile,
                "risk_score": risk,
                "priority": priority,
                "reason": reason,
                "deviation_rate": round(deviation, 4),
                "anomaly_rate": round(anomaly_rate, 4),
                "predicted_gas": round(float(expected.sum()), 1),
                "actual_gas": round(float(actual.sum()), 1),
                "suspected_loss_gas": round(loss, 1),
                "loss_low": round(loss * 0.94, 1),
                "loss_high": round(loss * 1.06, 1),
                "recovery_amount": round(loss * price, 2),
                "recovery_type": recovery_type,
                "recovery_advice": recovery_advice,
                "abnormal_start": next((dates[i].isoformat() for i in recent if float(rows[i]["meter_reading_m3"]) < predicted[i] * 0.72), recent_start.isoformat()),
                "series": series,
            })
        results.sort(key=lambda item: item["risk_score"], reverse=True)
        return {
            "model": {
                "name": "Temporal-MLP v1",
                "architecture": "10 → 24 ReLU → 12 ReLU → 1",
                "training_rows": int(sum(day <= cutoff for day in dates)),
                "epochs": self.epochs,
                "mae": round(mae, 2),
                "rmse": round(rmse, 2),
                "trained_at": datetime.now().isoformat(timespec="seconds"),
                "note": "演示模型基于导入数据即时训练；生产环境建议替换为经验证的 LSTM/Transformer 服务。",
            },
            "source": {"row_count": len(rows), "user_count": len(profile_rows), "latest_date": max_date.isoformat()},
            "users": results,
        }
