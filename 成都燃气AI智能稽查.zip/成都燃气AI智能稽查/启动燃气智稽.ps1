$ErrorActionPreference = 'Stop'
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonExe = 'C:\Users\J11\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) { $pythonExe = 'python' }

$serviceUrl = 'http://127.0.0.1:4173/api/health'
$running = $false
try { Invoke-WebRequest -UseBasicParsing -Uri $serviceUrl -TimeoutSec 1 | Out-Null; $running = $true } catch { }

if (-not $running) {
  Start-Process -FilePath $pythonExe -ArgumentList @('server.py') -WorkingDirectory $appDir -WindowStyle Minimized | Out-Null
  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 250
    try { Invoke-WebRequest -UseBasicParsing -Uri $serviceUrl -TimeoutSec 1 | Out-Null; $running = $true; break } catch { }
  }
}

if (-not $running) {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show('服务启动失败，请确认 Python 已安装。', '燃气智稽') | Out-Null
  exit 1
}
Start-Process 'http://127.0.0.1:4173/'
