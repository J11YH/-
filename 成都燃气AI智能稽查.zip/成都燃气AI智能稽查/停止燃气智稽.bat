@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0停止燃气智稽.ps1"
pause
