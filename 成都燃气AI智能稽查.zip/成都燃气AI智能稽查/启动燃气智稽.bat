@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0启动燃气智稽.ps1"
exit /b %errorlevel%
