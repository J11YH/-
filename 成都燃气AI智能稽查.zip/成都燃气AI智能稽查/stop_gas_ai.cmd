@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop_gas_ai.ps1"
pause
