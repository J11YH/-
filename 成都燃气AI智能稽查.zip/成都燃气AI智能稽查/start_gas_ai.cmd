@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_gas_ai.ps1"
