$appProcesses = Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -like '*gas-ai-app*server.py*' }
if ($appProcesses) {
  $appProcesses | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
  Write-Host 'Gas AI service stopped.'
} else {
  Write-Host 'Gas AI service is not running.'
}
