from __future__ import annotations

import json
import mimetypes
import os
import shutil
import sys
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from model import NeuralGasModel


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
RUNTIME_DIR = BASE_DIR / "runtime"
DEFAULT_BOOK = BASE_DIR / "sample_gas_data.xlsx"
CURRENT_BOOK = RUNTIME_DIR / "current_import.xlsx"
STATE: dict = {"result": None, "file_name": None, "error": None}
DEMO_USERS = {"admin": "gas-ai-2026", "inspector": "gas-ai-2026"}


def read_workbook(path: Path):
    book = load_workbook(path, data_only=True, read_only=True)
    required = {"用户档案", "用气日数据"}
    missing = required.difference(book.sheetnames)
    if missing:
        raise ValueError(f"缺少工作表：{', '.join(sorted(missing))}")

    def sheet_rows(name):
        sheet = book[name]
        values = sheet.iter_rows(values_only=True)
        headers = [str(value).strip() if value is not None else "" for value in next(values)]
        return [{headers[i]: value for i, value in enumerate(row) if headers[i]} for row in values if any(value is not None for value in row)]

    profiles = sheet_rows("用户档案")
    usage = sheet_rows("用气日数据")
    profile_required = {"user_id", "user_name", "user_type", "region", "contract_capacity_m3", "gas_price_yuan"}
    usage_required = {"user_id", "date", "temperature_c", "is_holiday", "meter_reading_m3"}
    if not profiles or not profile_required.issubset(profiles[0]):
        raise ValueError("用户档案字段不完整，请使用示例模板")
    if not usage or not usage_required.issubset(usage[0]):
        raise ValueError("用气日数据字段不完整，请使用示例模板")
    known = {row["user_id"] for row in profiles}
    unknown = sorted({row["user_id"] for row in usage}.difference(known))
    if unknown:
        raise ValueError(f"用气数据包含未知用户：{', '.join(unknown[:5])}")
    return profiles, usage


def train_from(path: Path, file_name: str):
    profiles, usage = read_workbook(path)
    result = NeuralGasModel().fit_predict(usage, profiles)
    result["source"]["file_name"] = file_name
    STATE.update(result=result, file_name=file_name, error=None)


def build_clue_workbook(user: dict):
    book = Workbook()
    summary = book.active
    summary.title = "稽查线索摘要"
    detail = book.create_sheet("近90日用气曲线")
    model_sheet = book.create_sheet("模型说明")

    dark_fill = PatternFill("solid", fgColor="17343D")
    teal_fill = PatternFill("solid", fgColor="E6F4F1")
    orange_fill = PatternFill("solid", fgColor="FFF1E5")
    white_font = Font(name="Microsoft YaHei", color="FFFFFF", bold=True)
    title_font = Font(name="Microsoft YaHei", size=16, bold=True, color="17343D")
    body_font = Font(name="Microsoft YaHei", size=10, color="243238")
    label_font = Font(name="Microsoft YaHei", bold=True, color="52616B")
    thin = Side(style="thin", color="DFE4E8")

    summary.merge_cells("A1:D1")
    summary["A1"] = "AI偷盗气稽查线索"
    summary["A1"].font = title_font
    summary["A1"].alignment = Alignment(vertical="center")
    summary.row_dimensions[1].height = 30
    rows = [
        ("用户编号", user["user_id"], "用户名称", user["user_name"]),
        ("用户类型", user["user_type"], "所属区域", user["region"]),
        ("合同容量", f'{user["contract_capacity_m3"]} m³/日', "数据来源", STATE.get("file_name") or "当前导入数据"),
        ("偷盗气风险", f'{user["risk_score"]} 分', "稽查优先级", user["priority"]),
        ("异常开始日期", user["abnormal_start"], "预测偏差率", user["deviation_rate"]),
        ("异常日占比", user["anomaly_rate"], "疑似损失气量", user["suspected_loss_gas"]),
        ("正常预测气量", user["predicted_gas"], "实际计量气量", user["actual_gas"]),
        ("建议核定下限", user["loss_low"], "建议核定上限", user["loss_high"]),
        ("追缴预估金额", user["recovery_amount"], "追缴类型", user["recovery_type"]),
    ]
    for row_index, values in enumerate(rows, start=3):
        for column_index, value in enumerate(values, start=1):
            cell = summary.cell(row=row_index, column=column_index, value=value)
            cell.font = label_font if column_index in (1, 3) else body_font
            cell.fill = teal_fill if column_index in (1, 3) else PatternFill("solid", fgColor="FFFFFF")
            cell.border = Border(bottom=thin)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        summary.row_dimensions[row_index].height = 24
    summary["B8"].number_format = "0.0%"
    summary["D7"].number_format = "0.0%"
    for cell_ref in ("D8", "B9", "D9", "B10", "D10"):
        summary[cell_ref].number_format = "#,##0.0"
    summary["B11"].number_format = '¥#,##0.00'
    summary.merge_cells("A13:D13")
    summary["A13"] = "AI异常原因"
    summary["A13"].fill = dark_fill
    summary["A13"].font = white_font
    summary.merge_cells("A14:D15")
    summary["A14"] = user["reason"]
    summary["A14"].font = body_font
    summary["A14"].alignment = Alignment(wrap_text=True, vertical="top")
    summary.merge_cells("A17:D17")
    summary["A17"] = "稽查建议"
    summary["A17"].fill = dark_fill
    summary["A17"].font = white_font
    summary.merge_cells("A18:D20")
    summary["A18"] = f'按“{user["priority"]}”优先级安排现场稽查。AI结果仅作为线索，最终结论应结合现场表具、封印、管线和营业情况确认。'
    summary["A18"].font = body_font
    summary["A18"].fill = orange_fill
    summary["A18"].alignment = Alignment(wrap_text=True, vertical="top")
    summary.column_dimensions["A"].width = 18
    summary.column_dimensions["B"].width = 28
    summary.column_dimensions["C"].width = 18
    summary.column_dimensions["D"].width = 30
    summary.freeze_panes = "A3"
    summary.sheet_view.showGridLines = False

    detail.append(["日期", "实际计量气量(m³)", "AI正常预测气量(m³)", "日平均气温(℃)", "预测差额(m³)"])
    for point in user["series"]:
        detail.append([point["date"], point["actual"], point["predicted"], point["temperature"], max(point["predicted"] - point["actual"], 0)])
    for cell in detail[1]:
        cell.fill = dark_fill
        cell.font = white_font
        cell.alignment = Alignment(horizontal="center")
    for row in detail.iter_rows(min_row=2):
        for cell in row:
            cell.font = body_font
            cell.border = Border(bottom=thin)
        for cell in row[1:]:
            cell.number_format = "#,##0.0"
    detail.column_dimensions["A"].width = 16
    for column in ("B", "C", "D", "E"):
        detail.column_dimensions[column].width = 22
    detail.freeze_panes = "A2"
    detail.auto_filter.ref = detail.dimensions
    detail.sheet_view.showGridLines = False

    model = STATE["result"]["model"]
    model_rows = [
        ("模型名称", model["name"]),
        ("网络结构", model["architecture"]),
        ("训练样本", model["training_rows"]),
        ("训练轮次", model["epochs"]),
        ("训练集MAE", model["mae"]),
        ("训练集RMSE", model["rmse"]),
        ("模型训练时间", model["trained_at"]),
        ("线索导出时间", datetime.now().isoformat(timespec="seconds")),
        ("使用说明", model["note"]),
    ]
    model_sheet.append(["项目", "内容"])
    for row in model_rows:
        model_sheet.append(row)
    for cell in model_sheet[1]:
        cell.fill = dark_fill
        cell.font = white_font
    for row in model_sheet.iter_rows(min_row=2):
        row[0].font = label_font
        row[1].font = body_font
        row[1].alignment = Alignment(wrap_text=True, vertical="top")
    model_sheet.column_dimensions["A"].width = 20
    model_sheet.column_dimensions["B"].width = 76
    model_sheet.sheet_view.showGridLines = False

    buffer = BytesIO()
    book.save(buffer)
    return buffer.getvalue()


class Handler(BaseHTTPRequestHandler):
    server_version = "GasAI/1.0"

    def log_message(self, fmt, *args):
        sys.stdout.write("[GasAI] " + fmt % args + "\n")

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/data":
            if STATE["result"] is None:
                self.send_json({"error": STATE["error"] or "暂无可用数据"}, 503)
            else:
                self.send_json(STATE["result"])
            return
        if path == "/api/health":
            self.send_json({"status": "ok", "file_name": STATE["file_name"]})
            return
        if path == "/sample_gas_data.xlsx":
            self.send_file(DEFAULT_BOOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            return
        if path == "/api/export-clue":
            user_id = parse_qs(parsed.query).get("user_id", [None])[0]
            user = next((item for item in (STATE.get("result") or {}).get("users", []) if item["user_id"] == user_id), None)
            if user is None:
                self.send_json({"error": "未找到指定用户的稽查线索"}, 404)
                return
            data = build_clue_workbook(user)
            filename = quote(f'{user["user_name"]}_稽查线索.xlsx')
            self.send_bytes(data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", f"attachment; filename*=UTF-8''{filename}")
            return
        relative = "index.html" if path in ("/", "") else path.lstrip("/")
        target = (STATIC_DIR / relative).resolve()
        if STATIC_DIR.resolve() not in target.parents and target != STATIC_DIR.resolve():
            self.send_error(403)
            return
        if target.is_file():
            self.send_file(target, mimetypes.guess_type(str(target))[0] or "application/octet-stream")
        else:
            self.send_error(404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/login":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length) or b"{}")
                username = str(payload.get("username", "")).strip()
                password = str(payload.get("password", ""))
                if DEMO_USERS.get(username) != password:
                    self.send_json({"error": "账号或密码错误"}, 401)
                    return
                self.send_json({"ok": True, "username": username, "display_name": "稽查管理员" if username == "admin" else "现场稽查员"})
            except Exception:
                self.send_json({"error": "登录请求格式错误"}, 400)
            return
        if path not in ("/api/import", "/api/predict"):
            self.send_error(404)
            return
        try:
            if path == "/api/import":
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 30 * 1024 * 1024:
                    raise ValueError("文件为空或超过30MB")
                file_name = unquote(self.headers.get("X-File-Name", "uploaded.xlsx"))
                if not file_name.lower().endswith(".xlsx"):
                    raise ValueError("仅支持 .xlsx 文件")
                RUNTIME_DIR.mkdir(exist_ok=True)
                CURRENT_BOOK.write_bytes(self.rfile.read(length))
                train_from(CURRENT_BOOK, file_name)
            elif CURRENT_BOOK.exists():
                train_from(CURRENT_BOOK, STATE["file_name"] or "current_import.xlsx")
            else:
                train_from(DEFAULT_BOOK, DEFAULT_BOOK.name)
            self.send_json(STATE["result"])
        except Exception as exc:
            STATE["error"] = str(exc)
            traceback.print_exc()
            self.send_json({"error": str(exc)}, 400)

    def send_file(self, path: Path, content_type: str):
        self.send_bytes(path.read_bytes(), content_type)

    def send_bytes(self, data: bytes, content_type: str, disposition: str | None = None):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if disposition:
            self.send_header("Content-Disposition", disposition)
        self.end_headers()
        self.wfile.write(data)


def main():
    port = int(os.environ.get("GAS_AI_PORT", "4173"))
    RUNTIME_DIR.mkdir(exist_ok=True)
    source = CURRENT_BOOK if CURRENT_BOOK.exists() else DEFAULT_BOOK
    try:
        train_from(source, source.name)
    except Exception as exc:
        STATE["error"] = str(exc)
        print(f"Initial model failed: {exc}", file=sys.stderr)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"AI gas app running at http://127.0.0.1:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
